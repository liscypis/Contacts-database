var searchData=
[
  ['insertemail',['InsertEmail',['../add__and__remove__elements_8c.html#a17031d23a9addd4cbc8d7e533e1f5df6',1,'InsertEmail(struct email_node *FrontEmailList):&#160;add_and_remove_elements.c'],['../baza__kontaktow_8h.html#a74a24b21799a3c60875b617047c3037c',1,'InsertEmail(struct email_node *FrontEmailList):&#160;add_and_remove_elements.c']]],
  ['inserttelnum',['InsertTelNum',['../add__and__remove__elements_8c.html#ada2f470dde73553eceb80cbf90beea3a',1,'InsertTelNum(struct telephone_nr *FrontTelList):&#160;add_and_remove_elements.c'],['../baza__kontaktow_8h.html#a2422e13fa303b849f01271058f210585',1,'InsertTelNum(struct telephone_nr *FrontTelList):&#160;add_and_remove_elements.c']]],
  ['insertuser',['InsertUser',['../add__and__remove__elements_8c.html#a42d8e27da1953eaecb22dbd216840529',1,'InsertUser(struct User_Node *FrontUserList):&#160;add_and_remove_elements.c'],['../baza__kontaktow_8h.html#a440b366581935e520d62a4e35052f94b',1,'InsertUser(struct User_Node *FrontUserList):&#160;add_and_remove_elements.c']]]
];
