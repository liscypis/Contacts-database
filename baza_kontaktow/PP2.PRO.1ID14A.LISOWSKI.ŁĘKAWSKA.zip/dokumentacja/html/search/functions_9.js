var searchData=
[
  ['user_5fexist',['user_exist',['../baza__kontaktow_8h.html#a4d11ee910d336026d1bd40fee81af8d9',1,'user_exist(struct User_Node *FrontUserList, int data):&#160;operations_on_lists.c'],['../operations__on__lists_8c.html#a4d11ee910d336026d1bd40fee81af8d9',1,'user_exist(struct User_Node *FrontUserList, int data):&#160;operations_on_lists.c']]]
];
