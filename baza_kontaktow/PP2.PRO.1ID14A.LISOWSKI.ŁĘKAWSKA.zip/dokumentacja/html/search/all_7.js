var searchData=
[
  ['name_5fexist',['name_exist',['../baza__kontaktow_8h.html#ad488603dfea360822d096a4390b39f07',1,'name_exist(struct User_Node *FrontUserList, char data[]):&#160;operations_on_lists.c'],['../operations__on__lists_8c.html#ad488603dfea360822d096a4390b39f07',1,'name_exist(struct User_Node *FrontUserList, char data[]):&#160;operations_on_lists.c']]],
  ['numid',['NumID',['../baza__kontaktow_8h.html#afa775335f302e8068241a49e2ce057e9',1,'baza_kontaktow.h']]]
];
