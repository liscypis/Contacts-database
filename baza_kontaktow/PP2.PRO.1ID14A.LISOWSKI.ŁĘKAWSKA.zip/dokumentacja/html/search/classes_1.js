var searchData=
[
  ['telephone_5fnr',['telephone_nr',['../structtelephone__nr.html',1,'']]]
];
