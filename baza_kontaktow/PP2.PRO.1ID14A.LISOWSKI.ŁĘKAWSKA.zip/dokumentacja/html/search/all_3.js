var searchData=
[
  ['deleteemailnode',['DeleteEmailNode',['../add__and__remove__elements_8c.html#ae88f852ac9af6dfacc0ae9388e3e7a7f',1,'DeleteEmailNode(struct email_node *FrontEmailList, int data):&#160;add_and_remove_elements.c'],['../baza__kontaktow_8h.html#ab13bd8b997b526508b18903be757628e',1,'DeleteEmailNode(struct email_node *FrontEmailList, int data):&#160;add_and_remove_elements.c']]],
  ['deletetelnode',['DeleteTelNode',['../add__and__remove__elements_8c.html#a940ef97ae1b25429992629fa58b24424',1,'DeleteTelNode(struct telephone_nr *FrontTelList, int data):&#160;add_and_remove_elements.c'],['../baza__kontaktow_8h.html#aa9f7676aa2f5eeab9486dc01ea34475e',1,'DeleteTelNode(struct telephone_nr *FrontTelList, int data):&#160;add_and_remove_elements.c']]],
  ['deleteusernode',['DeleteUserNode',['../add__and__remove__elements_8c.html#a14ceadba06a78085a022509f55d5c94c',1,'DeleteUserNode(struct User_Node *FrontUserList, int data):&#160;add_and_remove_elements.c'],['../baza__kontaktow_8h.html#a0b62228ca8a408981f0ba7c2458e16bf',1,'DeleteUserNode(struct User_Node *FrontUserList, int data):&#160;add_and_remove_elements.c']]]
];
