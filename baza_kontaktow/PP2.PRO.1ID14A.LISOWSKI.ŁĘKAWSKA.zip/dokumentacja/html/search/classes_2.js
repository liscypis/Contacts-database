var searchData=
[
  ['user_5fnode',['User_Node',['../struct_user___node.html',1,'']]]
];
