var indexSectionsWithContent =
{
  0: "abcdeimnoprstu",
  1: "etu",
  2: "abmors",
  3: "cdeinprstu",
  4: "n"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Struktury Danych",
  2: "Pliki",
  3: "Funkcje",
  4: "Zmienne"
};

