var searchData=
[
  ['file',['file',['../baza__kontaktow_8h.html#a702945180aa732857b380a007a7e2a21',1,'baza_kontaktow.h']]],
  ['file2',['file2',['../baza__kontaktow_8h.html#aa6655aec9024087d7037e39d18786dbb',1,'baza_kontaktow.h']]],
  ['file3',['file3',['../baza__kontaktow_8h.html#ada5ed65953ed58ae0e7eba3bbd1fb904',1,'baza_kontaktow.h']]]
];
