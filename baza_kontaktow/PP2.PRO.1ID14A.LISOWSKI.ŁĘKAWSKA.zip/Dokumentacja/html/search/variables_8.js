var searchData=
[
  ['tel_5fnr',['tel_nr',['../structtelephone__nr.html#a9393124930480d49b94464b447d26579',1,'telephone_nr']]]
];
