var searchData=
[
  ['baza_5fkontaktow_2eh',['baza_kontaktow.h',['../baza__kontaktow_8h.html',1,'']]]
];
