var searchData=
[
  ['email_5fnode',['email_node',['../structemail__node.html',1,'']]]
];
