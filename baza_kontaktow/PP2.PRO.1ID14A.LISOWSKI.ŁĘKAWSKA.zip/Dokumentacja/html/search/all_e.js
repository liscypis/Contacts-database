var searchData=
[
  ['tel_5fexist',['tel_exist',['../baza__kontaktow_8h.html#a5fb3179dc8f606870a43567f925162a8',1,'tel_exist(struct telephone_nr *FrontTelList, int data):&#160;operations_on_lists.c'],['../operations__on__lists_8c.html#a5fb3179dc8f606870a43567f925162a8',1,'tel_exist(struct telephone_nr *FrontTelList, int data):&#160;operations_on_lists.c']]],
  ['tel_5fnr',['tel_nr',['../structtelephone__nr.html#a9393124930480d49b94464b447d26579',1,'telephone_nr']]],
  ['telephone_5fnr',['telephone_nr',['../structtelephone__nr.html',1,'']]]
];
