var searchData=
[
  ['name',['name',['../struct_user___node.html#a6bccb8d69041825bceb9c678a8d1134d',1,'User_Node']]],
  ['next',['next',['../struct_user___node.html#ac7b6dd6a80799cb1435e1634c25056da',1,'User_Node::next()'],['../structtelephone__nr.html#a6d629d1a8807cbaac0d983afbced5a5f',1,'telephone_nr::next()'],['../structemail__node.html#ac72aebdfb1767780ae8f57335f9db27e',1,'email_node::next()']]],
  ['numid',['NumID',['../baza__kontaktow_8h.html#afa775335f302e8068241a49e2ce057e9',1,'baza_kontaktow.h']]]
];
