var searchData=
[
  ['street',['street',['../struct_user___node.html#ae2f315532384ebd0e626f1a2dcdb9792',1,'User_Node']]],
  ['surname',['surname',['../struct_user___node.html#a357b067ae295da35557ab5216236ce73',1,'User_Node']]]
];
