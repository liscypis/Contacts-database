var searchData=
[
  ['city',['city',['../struct_user___node.html#a0769a023d08f71d68c3cd1b4d6f756f5',1,'User_Node']]]
];
