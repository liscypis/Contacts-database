var searchData=
[
  ['name_5fexist',['name_exist',['../baza__kontaktow_8h.html#ad488603dfea360822d096a4390b39f07',1,'name_exist(struct User_Node *FrontUserList, char data[]):&#160;operations_on_lists.c'],['../operations__on__lists_8c.html#ad488603dfea360822d096a4390b39f07',1,'name_exist(struct User_Node *FrontUserList, char data[]):&#160;operations_on_lists.c']]]
];
