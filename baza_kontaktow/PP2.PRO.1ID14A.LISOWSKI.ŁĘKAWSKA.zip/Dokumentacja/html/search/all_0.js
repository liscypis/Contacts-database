var searchData=
[
  ['add_5fand_5fremove_5felements_2ec',['add_and_remove_elements.c',['../add__and__remove__elements_8c.html',1,'']]]
];
