var searchData=
[
  ['edit_5fperson',['edit_person',['../baza__kontaktow_8h.html#a4fcc8ee697e7e6139fcec267f318cd8d',1,'edit_person(struct User_Node *FrontUserList, struct telephone_nr *FrontTelList, struct email_node *FrontEmailList, unsigned short int data):&#160;operations_on_lists.c'],['../operations__on__lists_8c.html#a4fcc8ee697e7e6139fcec267f318cd8d',1,'edit_person(struct User_Node *FrontUserList, struct telephone_nr *FrontTelList, struct email_node *FrontEmailList, unsigned short int data):&#160;operations_on_lists.c']]],
  ['em',['em',['../structemail__node.html#a2bfebf48bfdf859c9add425f0d306870',1,'email_node']]],
  ['email_5fexist',['email_exist',['../baza__kontaktow_8h.html#ab33f50f098f67fd355030b6a6b3ca35b',1,'email_exist(struct email_node *FrontEmailList, char data[]):&#160;operations_on_lists.c'],['../operations__on__lists_8c.html#ab33f50f098f67fd355030b6a6b3ca35b',1,'email_exist(struct email_node *FrontEmailList, char data[]):&#160;operations_on_lists.c']]],
  ['email_5fnode',['email_node',['../structemail__node.html',1,'']]]
];
